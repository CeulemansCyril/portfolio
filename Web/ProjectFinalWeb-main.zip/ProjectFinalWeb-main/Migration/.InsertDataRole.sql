insert into role values (1,'Admin'),
                        (2,'Teacher'),
                        (3,'Student'),
                        (4,'Guest'),
                        (5,'Banni');

insert into user_role value (1,1,1);