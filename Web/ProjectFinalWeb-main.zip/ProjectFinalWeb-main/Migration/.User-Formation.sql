create table if not EXISTS `user_formation`
(
    `id`      int not null AUTO_INCREMENT,
    `idUser`  int not null,
    `idForma` int not null,
    `dateInscription` varchar(30) not null,
    primary key (`id`),
    foreign key (`idUser`) references `user` (`idUser`) on delete cascade ,
    foreign key (`idForma`) references `formation` (`idForma`) on delete cascade
)ENGINE=InnoDB DEFAULT CHARSET=utf8;