create table if not EXISTS `cour_formation`
(
    `id`    int not null AUTO_INCREMENT,
    `idCour`  int not null,
    `idForma` int not null,
    primary key (`id`),
    foreign key (`idCour`) references `cour` (`idCour`) on delete cascade ,
    foreign key (`idForma`) references `formation` (`idForma`) on delete cascade
)ENGINE=InnoDB DEFAULT CHARSET=utf8;