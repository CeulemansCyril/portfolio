create table if not EXISTS `user_role`
(
    `id`    int not null AUTO_INCREMENT,
    `idUser` int not null,
    `idRole` int not null,
    primary key (`id`),
    foreign key (`idUser`) references `user` (`idUser`) on delete cascade ,
    foreign key (`idRole`) references `role` (`idRole`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;