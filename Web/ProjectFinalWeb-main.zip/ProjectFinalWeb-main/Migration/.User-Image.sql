create table if not exists user_image(
    `id` int not null auto_increment,
    `idIMG` int not null ,
    `idUser` int not null,
    primary key (`id`),
    foreign key (`idIMG`) references image(`id`) on delete cascade ,
    foreign key (`idUser`) references user(`idUser`) on delete cascade
)ENGINE=InnoDB DEFAULT CHARSET=utf8;