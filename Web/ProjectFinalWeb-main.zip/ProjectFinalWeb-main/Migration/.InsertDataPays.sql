INSERT Into Pays (idPays,PaysName) values
                                       ('USA','ÉTATS-UNIS'),
                                       ('ENG','ANGLETERRE'),
                                       ('CAN','CANADA'),
                                       ('AFS','AFRIQUE DU SUD'),
                                       ('IRL','IRLAND'),
                                       ('AUS','AUSTRALIE'),
                                       ('FRA','FRANCE'),
                                       ('BEL','BELGIQUE')
;

insert into user_pays value (1,'BEL',1);