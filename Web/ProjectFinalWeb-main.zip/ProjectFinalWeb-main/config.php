<?php

//nom du serveur
const DB_HOST = 'localhost';
// nom de la bd
const DB_NAME = 'webprojetfinal';
//nom de l'utilisateur
const DB_USER = 'root';
//mot de passe de l'utilisateur
const DB_PASSWORD = '';
const ROOT_PATH = __DIR__;

