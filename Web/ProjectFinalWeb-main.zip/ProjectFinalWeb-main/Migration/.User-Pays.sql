create table if not EXISTS `user_pays`(
    `id` int not null AUTO_INCREMENT,
    `idPays` varchar(3) not null,
    `idUser` int not null,
    primary key (`id`),
    foreign key (`idPays`) references `pays`(`idPays`),
    foreign key (`idUser`) references `user`(`idUser`) on delete cascade
)ENGINE=InnoDB DEFAULT CHARSET=utf8;