insert into user value
    (1,'toto','$2y$10$Sj4Aik/zLcmZatuPPr8dauECamiRgDZSxZnW0XIN./m5Mk90J133G','toto@toto.com','Jojo','Koe','BEL','1999-09-19'
    ,'new orison','4852185','en',now());

insert into user_role value (1,1,1);